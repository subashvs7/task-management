<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\task-last\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>